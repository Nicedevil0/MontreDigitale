package sourcesTP2;

public class Horaire implements Comparable
{
    private int heures;
    private int minutes;
    private int secondes;

    public Horaire(int h, int m, int s){
        this.heures = h;
        this.minutes = m;
        this.secondes = s;
    }

	@Override
	public int compareTo(Object o) {
		return this.heures*3600+this.minutes*60+this.secondes - (((Horaire)o).heures*3600+((Horaire)o).minutes*60+((Horaire)o).secondes);
	}
}