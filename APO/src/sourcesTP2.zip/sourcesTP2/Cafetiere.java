package sourcesTP2;

public class Cafetiere extends Objet {
    public Cafetiere(String n) {
        super(n);
    }
}
