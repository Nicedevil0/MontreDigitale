package sourcesTP2;

public abstract class Declenchable
{
    public void declencher(){
        System.out.println("    - " + super.toString() + " s'est déclenché.");
    }
}
