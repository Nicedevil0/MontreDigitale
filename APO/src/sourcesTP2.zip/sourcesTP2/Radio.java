package sourcesTP2;

public class Radio extends Objet{
    public Radio(String n) {
        super(n);
    }
}
