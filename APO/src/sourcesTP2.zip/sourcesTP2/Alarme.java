package sourcesTP2;

public class Alarme extends Objet {
    public Alarme(String n){
        super(n);
    }
}
