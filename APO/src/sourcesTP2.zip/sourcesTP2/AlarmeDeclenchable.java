package sourcesTP2;

public class AlarmeDeclenchable extends Declenchable{

    private final Alarme alarme;

    public AlarmeDeclenchable(Alarme a){
        this.alarme = a;
    }

    @Override
    public void declencher() {
        System.out.println("    - L'alarme \"" + this.alarme.toString() + "\" sonne.");
    }
}
