package sourcesTP2;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class Reveil extends Montre
{
    private boolean estActif;
    private Horaire heureDeclenchage;

    public void addDeclenchables(Declenchable declenchable) {
        this.declenchables.add(declenchable);
    }

    public void removeDeclenchables(Declenchable declenchable) {
        this.declenchables.remove(declenchable);
    }

    private List<Declenchable> declenchables;

    public Reveil()
    {
        super();
        this.declenchables = new ArrayList<>();
    }

    public Reveil(Horaire heureDeclenchage)
    {
        super();
        this.heureDeclenchage = heureDeclenchage;
        this.declenchables = new ArrayList<>();
    }

    @Override
    public void run()
    {
        estDemarree = true;
        while(estDemarree){
            try{
                TimeUnit.MILLISECONDS.sleep(1000);
            }catch(Exception e){
                System.out.println("Il y a eu un problème dans la montre...");
            }
            this.incrementer();
            System.out.println("Heure actuelle : " + this.toString());
            if (estActif && heureDeclenchage.compareTo(this.getHoraire()) == 0) {
                declencher();
                this.desactiver();
            }
        }

    }

    public void activer()
    {
        estActif = true;
    }

    public void setHeureDeclenchage(Horaire h){
        this.heureDeclenchage = h;
    }

    public void desactiver()
    {
        if (this.estActif)
        {
            this.estActif = false;
        }
    }

    public void declencher()
    {
        System.out.println("IL EST " + super.toString() + ", déclenchement des opérations suivantes :");
        for (Declenchable d : this.declenchables){
            d.declencher();
        }
    }
}
