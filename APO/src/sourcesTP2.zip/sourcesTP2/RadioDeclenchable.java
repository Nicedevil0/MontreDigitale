package sourcesTP2;

public class RadioDeclenchable extends Declenchable{

    private final Radio radio;

    public RadioDeclenchable(Radio a){
        this.radio = a;
    }

    @Override
    public void declencher() {
        System.out.println("    - La radio \"" + this.radio.toString() + "\" s'allume.");
    }
}
