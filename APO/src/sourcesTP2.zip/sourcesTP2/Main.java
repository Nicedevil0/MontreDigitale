package sourcesTP2;

public class Main 
{
    public static void main( String[] args )
    {
        Reveil r = new Reveil(new Horaire(0, 0, 10));
        r.addDeclenchables(new AlarmeDeclenchable(new Alarme("Ding dong")));
        r.addDeclenchables(new RadioDeclenchable(new Radio("VIRGIN Radio")));
        r.addDeclenchables(new CafetiereDeclenchable(new Cafetiere("Senseo")));
        r.activer();
        r.run();
    }
}
